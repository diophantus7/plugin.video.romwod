# ROMWOD plugin for Kodi mediacenter

This is a video plugin [ROMWOD](http://romwod.com) for [kodi](http://kodi.tv) mediacenter.
[ROMWOD](http://romwod.com) features daily online Yin stretching routines for athletes.
Based on ancient Kung Fu techniques that strengthen and open joints resulting in optimal
range of motion.
The use of this plugin requires a sign-up on http://romwod.com. You can start a
14-day trial [here](https://romwod.com/members/signup/extended-trial)

**Note**: This plugin requieres python-requests and python-beautifulsoup to be installed.

License: [GPL v.3](http://www.gnu.org/copyleft/gpl.html)
