import os
import urlparse

class SettingsHandler():
    pass